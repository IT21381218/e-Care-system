package com.patient;

public class Patient {
	private int p_id;
	private String p_name;
	private String username;
	private String p_email;
	private String password;
	private String nic;
	private String p_phone;

	
	public Patient (int p_id, String p_name, String username,String p_email, String password, String nic,String p_phone) {
		this. p_id= p_id;
		this. p_name= p_name;
		this. username= username;
		this. p_email= p_email;
		this. password= password;
		this. nic= nic;
		this. p_phone= p_phone;
	}


	public int getP_id() {
		return p_id;
	}

	public String getP_name() {
		return p_name;
	}

	public String getUsername() {
		return username;
	}

	public String getP_email() {
		return p_email;
	}

	public String getPassword() {
		return password;
	}

	public String getNic() {
		return nic;
	}

	public String getP_phone() {
		return p_phone;
	}

}

