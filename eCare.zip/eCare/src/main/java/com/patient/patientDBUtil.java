package com.patient;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;


public class patientDBUtil {
	public static List<Patient> validate(String username, String password){
		
		ArrayList<Patient> p = new ArrayList<>();
			String url = "jdbc:mysql://localhost:3306/ecare";
			String user = "root";
			String pass = "Ekzetef@4318";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection(url,user,pass);
			Statement stmt = con.createStatement();
			String sql = "select * from patient where username = '"+username+"' and password='"+password+"'";
			ResultSet rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String userName = rs.getString(3);
				String email = rs.getString(4);
				String password1 = rs.getString(5);
				String nic = rs.getString(6);
				String phone = rs.getString(7);
				
				Patient p1 = new Patient(id, name, userName, email, password1, nic, phone);
				p.add(p1);
			}
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return p;
	}
	
	public static boolean insertPatient(String name, String username, String email, String password,String nic, String phone ) {
		boolean isSuccess = false;
		
		//create db connection
		
		String url = "jdbc:mysql://localhost:3306/ecare";
		String user = "root";
		String pass = "Ekzetef@4318";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection(url,user,pass);
			Statement stmt = con.createStatement();
			String sql = "insert into patient values(0,'"+name+"','"+username+"','"+email+"','"+password+"','"+nic+"','"+phone+"')";
			int rs = stmt.executeUpdate(sql);
			
			if(rs > 0) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
	}
	
	
}
